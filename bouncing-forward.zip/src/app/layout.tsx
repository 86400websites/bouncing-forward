import type { Metadata } from "next";
import "./globals.css";
import { bodyFont, displayFont } from "@/lib/fonts";
import { MotionProvider } from "@/components/motion/motion-provider";
import { SiteFooter } from "@/components/site/site-footer";
import { SiteHeader } from "@/components/site/site-header";
import { PageFoot } from "@/components/site/page-foot";
import { SITE_NAME, SITE_URL } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Bouncing Forward | Setbacks Don’t Get the Last Word",
    template: `%s · ${SITE_NAME}`,
  },
  description:
    "The setback wasn’t your choice. The next step is. Built from a real story, for anyone in their hardest chapter.",
  openGraph: {
    type: "website",
    siteName: SITE_NAME,
    title: "Bouncing Forward | Setbacks Don’t Get the Last Word",
    description:
      "The setback wasn’t your choice. The next step is. Built from a real story, for anyone in their hardest chapter.",
    images: [{ url: "/assets/book/cover-3d.jpeg" }],
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${displayFont.variable} ${bodyFont.variable}`}>
      <body className="antialiased">
        <a
          href="#main"
          className="focus:bg-primary focus:text-primary-foreground sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-md focus:px-4 focus:py-2"
        >
          Skip to content
        </a>
        <MotionProvider>
          <SiteHeader />
          <main id="main">{children}</main>
          <PageFoot />
          <SiteFooter />
        </MotionProvider>
      </body>
    </html>
  );
}
